function throwDice() {
    var tiradaDados;
    tiradaDados = Math.floor(Math.random() * ((6 - 1) + 1) + 1);
//    tiradaDados = null;
//    tiradaDados = 'pepe';
//    tiradaDados = 0;
//      tiradaDados = 7;

    return tiradaDados;
}
//console.log('dados: '+ throwDice());
